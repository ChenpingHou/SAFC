function softmaxModel = SAFC_D(W1,train_data,train_label,alpha,beta)
%% Input:
% W1: c*d1, a model learned in previous stage, and it will be reused in
%     current stage. W1 can be learned by using 'mysoftmax' function.
%     c and d1 are the number of classes and the dimension of data in
%     previous stage, respectively.
% train_data: d2*n, where d2 is the dimension of data in current stage, d2 > d1.
%             n is the number of data in current stage.
% train_label: (c+1)*n, each column is a one-hot vector.
% alpha and beta: the hyperparameters in the model, alpha > 0, beta >0.
% eta: the step size in the gradient descent algorithm.
%% Output:
%  softmaxModel: (c+1)*d, the learned classifier.
%% Our proposed method
cost_old = 0; %set old cost and new cost value
cost = 1;
object_value = [];% record the cost at each update iteration
count = 0; % count the running number
[nCla1,nFea1] = size(W1);
[nCla2,nSam2] = size(train_label);
nFea2 = size(train_data,1);
X_21 = train_data(1:nFea1,:);
X_22 = train_data(nFea1+1:end,:);
W2 = 0.005*ones(nCla2,nFea2); %  Initialise classifier W
% [W2,~] = mysoftmax( data_s2,label_s2,alpha_set, eta);
W21 = W2(:,1:nFea1);
W22 = W2(:,nFea1+1:end);
W21_tilde = W21(1:nCla1,:);
W21_hat = W21(nCla1+1,:);
W22_tilde = W22(1:nCla1,:);
W22_hat = W22(nCla1+1,:);
loop_max=3000;
eta = exp(-1);
while (abs(cost_old - cost) > 10^-6 && count < loop_max )
    cost_old = cost;
    count=count+1;
    M = bsxfun(@minus,W2*train_data,max(W2*train_data, [], 1));
    M = exp(M);
    p = bsxfun(@rdivide, M, sum(M));
    cost = -1/nSam2 * train_label(:)' * log(p(:)) +alpha * sum(W2(:) .^ 2)+ beta * sum((W21_tilde(:)-W1(:)) .^ 2);
    W21_tilde_grad = -1/nSam2 * (train_label(1:nCla1,:) - p(1:nCla1,:)) * X_21' + 2*alpha*W21_tilde + 2*beta * (W21_tilde-W1);
    W21_hat_grad =  -1/nSam2 * (train_label(nCla1+1,:) - p(nCla1+1,:)) * X_21' + 2*alpha*W21_hat;
    W22_grad = -1/nSam2 * (train_label - p) * X_22' + 2*alpha * W22;
    eta = find_eta(train_data,train_label,alpha,beta,W21_tilde_grad,W21_hat_grad,W22_grad,W21_tilde,W21_hat,W22,W1,cost,eta);
    W21_tilde = W21_tilde - eta*W21_tilde_grad;
    W21_hat = W21_hat - eta*W21_hat_grad;
    W22 = W22 - eta*W22_grad;
    W21 = [W21_tilde;W21_hat];
    W2 = [W21 W22];
    object_value = [object_value;cost];
end
softmaxModel = W2;
end

function eta_find = find_eta(train_data,train_label,alpha,beta,W21_tilde_grad,W21_hat_grad,W22_grad,W21_tilde,W21_hat,W22,W1,cost_before,eta)
[n_Fea,nSam] = size(train_data);
W21_tilde_temp = W21_tilde - eta*W21_tilde_grad;
W21_hat_temp = W21_hat - eta*W21_hat_grad;
W22_temp = W22 - eta*W22_grad;
W21_temp = [W21_tilde_temp;W21_hat_temp];
W2_temp = [W21_temp W22_temp];
M = bsxfun(@minus,W2_temp*train_data,max(W2_temp*train_data, [], 1));
M = exp(M);
p = bsxfun(@rdivide, M, sum(M));
cost_after = -1/nSam * train_label(:)' * log(p(:)) +alpha * sum(W2_temp(:) .^ 2)+ beta * sum((W21_tilde_temp(:)-W1(:)) .^ 2);
while cost_after > cost_before
    eta = 0.5*eta;
    W21_tilde_temp = W21_tilde - eta*W21_tilde_grad;
    W21_hat_temp = W21_hat - eta*W21_hat_grad;
    W22_temp = W22 - eta*W22_grad;
    W21_temp = [W21_tilde_temp;W21_hat_temp];
    W2_temp = [W21_temp W22_temp];
    M = bsxfun(@minus,W2_temp*train_data,max(W2_temp*train_data, [], 1));
    M = exp(M);
    p = bsxfun(@rdivide, M, sum(M));
    cost_after = -1/nSam * train_label(:)' * log(p(:)) +alpha * sum(W2_temp(:) .^ 2)+ beta * sum((W21_tilde_temp(:)-W1(:)) .^ 2);
end
eta_find = eta;
end