function [softmaxModel,alpha_best] = mysoftmax( train_data,train_label,alpha_set)
%% Input:
% train_data: d*n, where d is the dimension of data.
%             n is the number of data.
% train_label: c*n, each column is a one-hot vector. 
% alpha_set: the hyperparameters set, which is used for cross-validation.
% eta: the step size in the gradient descent algorithm.
%% Output:
%  softmaxModel: c*d, the learned classifier.
%  alpha_best: the best hyperparameter determined by cross-validation.
%% cross validation
if length(alpha_set)>1
    alpha_num = length(alpha_set);
    n = size(train_data,2);
    k_fold = 5;
    Indices = crossvalind('Kfold', n, k_fold);
    acc_statistic = zeros(alpha_num,1);
    for k = 1:k_fold
        x_train = train_data(:,~(Indices==k));y_train = train_label(:,~(Indices==k));
        x_test = train_data(:,Indices==k);y_test = train_label(:,Indices==k);
        for i = 1:alpha_num
            alpha = alpha_set(i);
            w_i = find_best_w(x_train,y_train,alpha);
            [~,acc_i] = Predict(w_i,x_test, y_test);
            acc_statistic(i) = acc_statistic(i)+acc_i;
        end
    end
    index = find(acc_statistic==max(acc_statistic));
    alpha_position = index(1);
    alpha_best = alpha_set(alpha_position);
    softmaxModel = find_best_w( train_data,train_label, alpha_best);
else
    alpha_best = alpha_set;
    softmaxModel = find_best_w( train_data,train_label, alpha_best);
end
end

function W1 = find_best_w( train_data,train_label, alpha, eta)
[n_Fea,n_Sam] = size(train_data);
nCla = size(train_label,1);
W = 0.005*ones(nCla,n_Fea);
count=0;        % count the running number
%set old cost and new cost value
cost_old=0;
cost=1;
object_value=[];% record the cost at each update iteration
loop_max=3000;
eta = exp(-1);
while (abs(cost_old - cost) > 10^-6 && count < loop_max )
    %( abs(cost_old - cost) > 0.0001*cost ) &&
    cost_old = cost;
    count=count+1;
    M = bsxfun(@minus,W*train_data,max(W*train_data, [], 1));
    M = exp(M);
    p = bsxfun(@rdivide, M, sum(M));
    cost = -1/n_Sam * train_label(:)' * log(p(:)) + alpha * sum(W(:) .^ 2);
    W_grad = -1/n_Sam * (train_label - p) * train_data' + 2*alpha * W;
    eta = find_eta(train_data,train_label, alpha,W,W_grad,cost,eta);
    W = W - eta*W_grad;
    object_value=[object_value;cost];
end
W1 = W;
end

function eta_find = find_eta(x,y, alpha,W,W_grad,cost_before,eta)
[n_Fea,n_Sam] = size(x);
W_temp = W - eta*W_grad;
M = bsxfun(@minus,W_temp*x,max(W_temp*x, [], 1));
M = exp(M);
p = bsxfun(@rdivide, M, sum(M));
cost_after = -1/n_Sam * y(:)' * log(p(:)) + alpha * sum(W_temp(:) .^ 2);
while cost_after > cost_before
    eta = 0.5*eta;
    W_temp = W - eta*W_grad;
    M = bsxfun(@minus,W_temp*x,max(W_temp*x, [], 1));
    M = exp(M);
    p = bsxfun(@rdivide, M, sum(M));
    cost_after = -1/n_Sam * y(:)' * log(p(:)) + alpha * sum(W_temp(:) .^ 2);
end
eta_find = eta;
end

