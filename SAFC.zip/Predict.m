function [pred,acc] = Predict(softmaxModel, test_data,test_label)
%% Input:
% softmaxModel: the learned multi-class classifier.
% test_data: the d*n input data matrix, where each column test_data(:, i) corresponds to
%        a single test set
% test_label: the c*n input label matrix
% our code should produce the prediction matrix 
%% Output:
% pred: a n-dimension vector, where pred(i) is the prediction for the i-th test_data
% acc: the testing accuracy.

pred = zeros(1, size(test_data, 2));
%% ---------- SoftmaxPredict --------------------------------------
%  Compute pred assuming that the labels start from 1.
test_data = test_data(1:size(softmaxModel,2),:);
M = bsxfun(@minus,softmaxModel*test_data,max(softmaxModel*test_data, [], 1));
M = exp(M);
predall = bsxfun(@rdivide, M, sum(M));
[probablity ,pred] = max(predall);
test_label = vec2ind(test_label);
acc = mean(test_label(:) == pred(:));
% ---------------------------------------------------------------------

end

