%% demo of the SAFC
% This is the demo of paper"Incremental Learning for Simultaneous
% Augmentation of Feature and Class".
% If there are any problems, please feel free to contact Chenping Hou (hcpnudt@hotmail.com).
%% generate the dataset
clc
clear
dataname = 'scene';
load([dataname,'.mat'])
label = gnd;
X = M; % some original data matrix is represented as M.
v_past = 1;
v_new = 2;
%the choice of v_past and v_new for each data:
%dermatology: 12; MSRC_v1: 23,25; scene: 12, 15
x_past = cell2mat(X(v_past));
x_new = cell2mat(X(v_new));
data = [x_past x_new];

stdX = std(data); % standard deviation
idx1 = stdX~=0;
centrX = data-repmat(mean(data),size(data,1),1);
data(:,idx1) = centrX(:,idx1)./repmat(stdX(:,idx1),size(data,1),1);
data = (data-repmat(mean(data),size(data,1),1))./repmat(std(data),size(data,1),1);
data = data./repmat(sqrt(sum(data.*data,2)),1, size(data,2));
num_cir = 5;
ratio_select = 0.3;
alpha_set=10.^[-3:3];
alpha = 0.001;
beta=0.01;% this demo does not conduct cross validation.

num_cla = length(unique(label));
label(label ==0)=num_cla;
c = 1;
Acc_ours1 = [];Acc_ours2 = [];Acc_ours2 = [];
Acc_s2 = [];
Acc_Reform = [];Acc_SENC = [];Acc_HDA=[];
Acc_left = [];Acc_left1 = [];Acc_left2 = [];
data_s1 = [];label_s1 = [];
data_s2_all = [];label_s2_all = [];
test_data = [];test_label=[];
for i=1:num_cla
    A=data(label == i,:);
    B=label(label == i);
    len = length(B);
    ratio1 = floor(0.5*len);
    ratio2 = floor(0.8*len);
    data_s1 = [data_s1; A(1:ratio1,:)];
    label_s1 = [label_s1; B(1:ratio1)];
    data_s2_all = [data_s2_all; A(ratio1+1:ratio2,:)];
    label_s2_all = [label_s2_all; B(ratio1+1:ratio2)];
    test_data = [test_data; A(ratio2+1:end,:)];
    test_label = [test_label; B(ratio2+1:end)];
end
data_s1 = data_s1(:,1:size(x_past,2));
data_s1(label_s1==num_cla,:) = [];
label_s1(label_s1==num_cla) = [];
% change the label vector to 0-1 matrix:
test_label = full(ind2vec(test_label'));
label_s1 = full(ind2vec(label_s1'));
INDEX_s2=[];
[W1,~] = mysoftmax( data_s1',label_s1,alpha_set);% the learned classification model in stage 1
while c <= num_cir
    fprintf('Iteration: c=%f \n',c)
    % randomly seclect data from data_s2_all
    label_11 = label_s2_all(label_s2_all==1);
    temp = -length(label_11);
    data_s2=[];
    label_s2 = [];
    for ss = 1:num_cla
        AA = data_s2_all(label_s2_all==ss,:);
        BB = label_s2_all(label_s2_all==ss);
        len = length(BB);
        rand_s2 = randperm(len);
        index_s2 = rand_s2(1:floor(ratio_select*len));
        data_s2 = [data_s2;AA(index_s2,:)];
        label_s2 = [label_s2;BB(index_s2)];
    end
    % change the label vector to 0-1 matrix:
    label_s2 = full(ind2vec(label_s2'));
    %% train & test
    % our method 1
    w_ours1 = SAFC_D(W1,data_s2', label_s2,alpha,beta);% use the first regularizer
    [pred1,acc_ours1] = Predict(w_ours1, test_data',test_label);
    Acc_ours1 = [Acc_ours1;acc_ours1];
    % our method 2
    w_ours2 = SAFC_ID(W1,data_s2', label_s2,alpha,beta);% use the second regularizer
    [pred21,acc_ours2] = Predict(w_ours2, test_data',test_label);
    Acc_ours2 = [Acc_ours2;acc_ours2];
    c = c+1;
end
mAcc_ours1 = mean(Acc_ours1);
mAcc_ours2 = mean(Acc_ours2);